<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<table class="books">
    <thead>
        <tr>
            <th class="text-primary"></th>
            <th class="text-primary">ISBN</th>
            <th class="text-primary">Title</th>
            <th class="text-primary">Author</th>
            <th class="text-primary">Image</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($books) > 0): ?>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($book->id); ?></td>
                    <td class="text-center text-success"><?php echo e($book->isbn); ?></td>
                    <td class="text-center"><?php echo e($book->title); ?></td>
                    <td class="text-left"><?php echo e($book->author); ?></td>
                    <td class="text-center"><img src="<?php echo e(asset('/images/books/' . $book->image_url)); ?>" /></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td class="text-danger" colspan="5">No books !</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/books.blade.php ENDPATH**/ ?>