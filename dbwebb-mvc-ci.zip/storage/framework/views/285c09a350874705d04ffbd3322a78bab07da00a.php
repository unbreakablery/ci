<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Home page</h1>
<p>Welcome to My Game21</p>
<h3>Dice FACES:</h3>
<p>
<?php $__currentLoopData = $diceImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $diceImg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $diceImg; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
<p>You can see my code on <a href="https://github.com/beha20/framework">Github</a></p>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/homepage.blade.php ENDPATH**/ ?>