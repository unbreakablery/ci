<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="text-success">Game History</h1>
<hr />
<h3>Total Games: <?php echo e($yourWins + $computerWins); ?></h3>
<h3 class="text-success">Your wins: <?php echo e($yourWins); ?></h3>
<h3 class="text-info">Computer wins: <?php echo e($computerWins); ?></h3>
<hr />
<h3 class="text-success">Your Balance: <?php echo e($yourBalance); ?></h3>
<h3 class="text-info">Computer wins: <?php echo e($computerBalance); ?></h3>

<table class="history">
    <thead>
        <tr>
            <th class="text-primary">#</th>
            <th class="text-primary">Date</th>
            <th class="text-primary">Winner</th>
            <th class="text-primary">Your Points</th>
            <th class="text-primary">Computer Points</th>
            <th class="text-primary">Bet Amount</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($history) > 0): ?>
            <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($idx + 1); ?></td>
                    <td class="text-center"><?php echo e($h->date); ?></td>
                    <td class="text-center"><?php echo e($h->winner); ?></td>
                    <td class="text-right"><?php echo e($h->point1); ?></td>
                    <td class="text-right"><?php echo e($h->point2); ?></td>
                    <td class="text-right"><?php echo e($h->bet_amount); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td class="text-italic text-danger text-center" colspan="6">No History !</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<p class="btn-wrapper">
    <a href="<?php echo e(route('game21')); ?>" class="success-link">New Game</a>
    <a href="<?php echo e(route('game21-clear-history')); ?>" class="danger-link">Clear History</a>
</p>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/game21/history.blade.php ENDPATH**/ ?>