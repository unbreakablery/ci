    </main>
    <footer>
        <p>Copyright &copy; 2021 Benaris Hajduk</p>
    </footer>
</body>
</html><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/footer.blade.php ENDPATH**/ ?>