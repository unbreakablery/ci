<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="text-success">Dice Game was Ended!</h1>

<h2 class="text-italic"><?php echo e($message); ?></h2>
<p>Your points: <?php echo e($yourPoints); ?></p>
<p>Computer points: <?php echo e($computerPoints); ?></p>
<h3 class="text-italic text-info"><?php echo e($highScoreMsg); ?></h3>
<hr />
<p>Your Balance: <?php echo e($yourBalance); ?></p>
<p>Computer Balance: <?php echo e($computerBalance); ?></p>

<h2>Game History</h2>
<p>Your wins: <?php echo e($yourWins); ?></p>
<p>Computer wins: <?php echo e($computerWins); ?></p>
<p class="btn-wrapper">
    <a href="<?php echo e(route('game21')); ?>" class="success-link">New Game</a>
    <a href="<?php echo e(route('game21-view-history')); ?>" class="info-link">View History</a>
    <a href="<?php echo e(route('game21-clear-history')); ?>" class="danger-link">Clear History</a>
</p>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/game21/result.blade.php ENDPATH**/ ?>