<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Game21">
    <meta name="author" content="Benaris Hajduk">
    <meta name="robots" content="noindex, nofollow">

    <title><?php echo e($pageName); ?></title>

    <link rel="shortcut icon" href="<?php echo e(asset('/favicon.ico')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('/favicon.ico')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/style.css')); ?>">
</head>

<body>

<header>
    <nav>
        <a href="<?php echo e(route('landing-page')); ?>" class="<?php if(isset($menuHomeClass) && $menuHomeClass == 'selected'): ?> selected <?php endif; ?>">Home</a>
        <a href="<?php echo e(route('game21')); ?>" class="<?php if(isset($menuGame21Class) && $menuGame21Class == 'selected'): ?> selected <?php endif; ?>">Game 21</a>
        <a href="<?php echo e(route('game21-view-history')); ?>" class="<?php if(isset($menuHistoryClass) && $menuHistoryClass == 'selected'): ?> selected <?php endif; ?>">Game History</a>
        <a href="<?php echo e(route('game21-view-highscores')); ?>" class="<?php if(isset($menuHighscoresClass) && $menuHighscoresClass == 'selected'): ?> selected <?php endif; ?>">High Scores</a>
        <a href="<?php echo e(route('game21-view-help')); ?>" class="<?php if(isset($menuHelpClass) && $menuHelpClass == 'selected'): ?> selected <?php endif; ?>">Help</a>
    </nav>
</header>
<main><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/header.blade.php ENDPATH**/ ?>