<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Game 21</h1>
<h3>Game Setting</h3>

<form action="<?php echo e(route('game21-save-setting')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <p>
        <label for="cnt-dices">Number of Dices: </label>
        <select name="cnt-dices" id="cnt-dices">
            <?php for($i = 1; $i <= 2; $i++): ?>
            <option value="<?php echo e($i); ?>" <?php if($i == $settings->cnt_dices): ?> <?php echo e('selected'); ?> <?php endif; ?>><?php echo e($i); ?></option>
            <?php endfor; ?>
        </select>
    </p>
    <p>
        <label for="dice-type">Dice Type: </label>
        <select name="dice-type" id="dice-type">
            <option value="graphical" selected>Graphical</option>
        </select>
    </p>
    <p>
        <label for="dice-type">Bet Amount: </label>
        <input type="number" class="bet-amount" name="bet-amount" placeholder="Max: 50% of your bitcoins" min="0" max="<?php echo e($settings->coin1 / 2); ?>" step="0.01" required /> (Your BTC: <?php echo e($settings->coin1); ?>)
    </p>
    <p class="btn-wrapper">
        <button type="submit" class="btn-submit">Save</button>
    </p>
</form>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/game21/setting.blade.php ENDPATH**/ ?>