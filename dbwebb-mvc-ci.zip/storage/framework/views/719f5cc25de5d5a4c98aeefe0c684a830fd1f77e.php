<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Welcome to Dice Game</h1>
<h2 class="text-italic">please, play this dice game!</h2>
<hr />
<h3>Your Points: <?php echo e($yourPoints); ?></h3>
<h3>Computer Points: <?php echo e($computerPoints); ?></h3>
<hr />
<h3>Your Bet Amount: <?php echo e($yourBetAmount); ?></h3>
<h3>Computer Bet Amount: <?php echo e($computerBetAmount); ?></h3>
<h3>Selected Bet Amount: <?php echo e($betAmount); ?></h3>
<hr />
<h3>Your Wins: <?php echo e($yourWins); ?></h3>
<h3>Computer Wins: <?php echo e($computerWins); ?></h3>
<hr />
<h3>Your Balance: <?php echo e($yourBalance); ?></h3>
<h3>Computer Balance: <?php echo e($computerBalance); ?></h3>

<p class="btn-wrapper">
    <a href="<?php echo e(route('game21-player-roll')); ?>" class="success-link">Roll, Your turn</a>
    <a href="<?php echo e(route('game21-computer-play')); ?>" class="danger-link">Stop, Computer turn</a>
</p>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/game21/start.blade.php ENDPATH**/ ?>