<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="text-success">High Scores</h1>

<table class="highscores">
    <thead>
        <tr>
            <th class="text-primary">Rank</th>
            <th class="text-primary">Date</th>
            <th class="text-primary">Player</th>
            <th class="text-primary">Score</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($highScores) > 0): ?>
            <?php $__currentLoopData = $highScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $highScore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($idx + 1); ?></td>
                    <td class="text-center"><?php echo e($highScore->date); ?></td>
                    <td class="text-center"><?php echo e($highScore->player); ?></td>
                    <td class="text-right"><?php echo e($highScore->score); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <tr>
                <td class="text-italic text-danger text-center" colspan="4">No High Scores !</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<p class="btn-wrapper">
    <a href="<?php echo e(route('game21')); ?>" class="success-link">New Game</a>
    <a href="<?php echo e(route('game21-clear-highscores')); ?>" class="danger-link">Clear HighScores</a>
</p>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/game21/highscores.blade.php ENDPATH**/ ?>