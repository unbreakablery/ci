<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1>Dice Hand!!!</h1>
<h2 class="text-italic">You got points: <?php echo e($points); ?></h2>
<p>
    <?php $__currentLoopData = $diceImgs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $img; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
<h2><?php echo e($message); ?></h2>

<h3>Your Points: <?php echo e($yourPoints); ?></h3>
<h3>Computer Points: <?php echo e($computerPoints); ?></h3>

<?php if(!$gameEnded): ?>
<p class="btn-wrapper">
    <a href="<?php echo e(route('game21-player-roll')); ?>" class="success-link">Roll, Your turn</a>
    <a href="<?php echo e(route('game21-computer-play')); ?>" class="danger-link">Stop, Computer turn</a>
</p>
<?php else: ?>
<p class="btn-wrapper">
    <a href="<?php echo e(route('game21-view-result')); ?>" class="info-link">View Result</a>
</p>
<?php endif; ?>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\projects\dbwebb-mvc-ci\resources\views/game21/dice.blade.php ENDPATH**/ ?>