    </main>
    <footer>
        <p>Copyright &copy; 2021 Benaris Hajduk</p>
    </footer>
</body>
</html>